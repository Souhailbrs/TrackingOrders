<section class='aposh-pricing' id='price'>
    <div class='container'>
        <div class='row'>
            <div class='col-lg-8 offset-lg-2 sec-titile-wrapper text-center'>
                <h2 class='section-title'>Appos Pricing</h2>
                <p>Lorem ipsum dolor sit amet consetetur sadipscing elitr sed diam nonumy eirmod tempor invidunt labore
                    dolore magna aliquyam erat sed diam voluptua.</p>
            </div>
            <!-- end section-titile -->
            <div class='col-lg-4 col-md-6 col-sm-6 col-12 text-center animation' data-animation='fadeInUp'
                 data-animation-delay='0.1s'>
                <div class='single-price-table'>
                    <div class='price-header'>
                        <h4>Stater Plan</h4>
                        <h3>FREE <span> FOREVER</span></h3>
                    </div>
                    <!-- end price header -->
                    <div class='price-body'>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr sed diam nonumy eirmod tempor
                            inviduntrebum. </p>
                    </div>
                    <!-- end price body -->
                    <div class='price-footer'>
                        <a href='#'>CHOOSE</a>
                    </div>
                    <!-- end price footer -->
                </div>
            </div>
            <!-- end single pricicng -->
            <div class='col-lg-4 col-md-6 col-sm-6 col-12 text-center animation' data-animation='fadeInUp'
                 data-animation-delay='0.14s'>
                <div class='single-price-table'>
                    <div class='price-header'>
                        <h4>Enterprise Plan</h4>
                        <h3>$25 <span> MONTH</span></h3>
                    </div>
                    <!-- end price header -->
                    <div class='price-body'>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr sed diam nonumy eirmod tempor
                            inviduntrebum. </p>
                    </div>
                    <!-- end price body -->
                    <div class='price-footer'>
                        <a href='#'>CHOOSE</a>
                    </div>
                    <!-- end price footer -->
                </div>
            </div>
            <!-- end single pricicng -->
            <div class='col-lg-4 col-md-6 col-sm-6 col-12 text-center animation' data-animation='fadeInUp'
                 data-animation-delay='0.18s'>
                <div class='single-price-table'>
                    <div class='price-header'>
                        <h4>Unlimited Plan</h4>
                        <h3>$40 <span> MONTH</span></h3>
                    </div>
                    <!-- end price header -->
                    <div class='price-body'>
                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr sed diam nonumy eirmod tempor
                            inviduntrebum. </p>
                    </div>
                    <!-- end price body -->
                    <div class='price-footer'>
                        <a href='#'>CHOOSE</a>
                    </div>
                    <!-- end price footer -->
                </div>
            </div>
            <!-- end single pricicng -->
        </div>
    </div>
</section>
