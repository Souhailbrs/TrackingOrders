<section class='tean-area' id='team'>
    <div class='container'>
        <div class='row'>
            <div class='col-lg-8 offset-lg-2 sec-titile-wrapper text-center'>
                <h2 class='section-title'>Experts Team</h2>
                <p>Lorem ipsum dolor sit amet consetetur sadipscing elitr sed diam nonumy eirmod tempor invidunt labore
                    dolore magna aliquyam erat sed diam voluptua.</p>
            </div>
            <!-- end section-titile -->
            <div class='col-lg-3 col-sm-6 col-12 text-center'>
                <div class='single-team-member'>
                    <figure class='teammember-tumb rounded-circle'>
                        <img src='{{asset('assets/site/images/all-img/tem1.png')}}' alt='' class='rounded-circle'>
                    </figure>
                    <h3><a href='#'>Mahedi Amin</a></h3>
                    <h5><span>front end developer</span></h5>
                    <ul>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='facebook'><i class='fa fa-facebook'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='twitter'><i class='fa fa-twitter'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='linkden'><i class='fa fa-linkedin'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='google pluse'><i class='fa fa-google-plus'
                                                                     aria-hidden='true'></i></a></li>
                    </ul>
                </div>
            </div>
            <!-- end single team member -->
            <div class='col-lg-3 col-sm-6 col-12 text-center'>
                <div class='single-team-member'>
                    <figure class='teammember-tumb rounded-circle'>
                        <img src='{{asset('assets/site/images/all-img/tem2.png')}}' alt='' class='rounded-circle'>
                    </figure>
                    <h3><a href='#'>Arina Merin</a></h3>
                    <h5><span>Co-Founder</span></h5>
                    <ul>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='facebook'><i class='fa fa-facebook'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='twitter'><i class='fa fa-twitter'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='linkden'><i class='fa fa-linkedin'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='google pluse'><i class='fa fa-google-plus'
                                                                     aria-hidden='true'></i></a></li>
                    </ul>
                </div>
            </div>
            <!-- end single team member -->
            <div class='col-lg-3 col-sm-6 col-12 text-center'>
                <div class='single-team-member'>
                    <figure class='teammember-tumb rounded-circle'>
                        <img src='{{asset('assets/site/images/all-img/tem3.png')}}' alt='' class='rounded-circle'>
                    </figure>
                    <h3><a href='#'>Tomoy Khan</a></h3>
                    <h5><span>UI Designer</span></h5>
                    <ul>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='facebook'><i class='fa fa-facebook'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='twitter'><i class='fa fa-twitter'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='linkden'><i class='fa fa-linkedin'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='google pluse'><i class='fa fa-google-plus'
                                                                     aria-hidden='true'></i></a></li>
                    </ul>
                </div>
            </div>
            <!-- end single team member -->
            <div class='col-lg-3 col-sm-6 col-12 text-center'>
                <div class='single-team-member'>
                    <figure class='teammember-tumb rounded-circle'>
                        <img src='{{asset('assets/site/images/all-img/tem4.png')}}' alt='' class='rounded-circle'>
                    </figure>
                    <h3><a href='#'>Nazmul Hasan</a></h3>
                    <h5><span>PHP Developer</span></h5>
                    <ul>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='facebook'><i class='fa fa-facebook'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='twitter'><i class='fa fa-twitter'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='linkden'><i class='fa fa-linkedin'></i></a></li>
                        <li><a href='#' data-toggle='tooltip' data-placement='top' title=''
                               data-original-title='google pluse'><i class='fa fa-google-plus'
                                                                     aria-hidden='true'></i></a></li>
                    </ul>
                </div>
            </div>
            <!-- end single team member -->
        </div>
    </div>
</section>
