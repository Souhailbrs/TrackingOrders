<?php

namespace App\Imports;

use App\Models\Order;
use App\Models\OrderProduct;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Imports\HeadingRowFormatter;

class OrdersImport implements ToModel, WithHeadingRow
{
    public $id;
    public function __construct($id){
        $this->id = $id;
    }

    public function model(array $row)
    {
         $order = Order::create([
            'sales_channel'=>$this->id,
            'customer_name'=> $row['customer_name'],
            'customer_phone1'=> $row['customer_phone'],
            'customer_phone2'=> $row['customer_phone'],
            'seller_notes'=> $row['seller_notes'],
            'notes'=>'',
            'status'=>0,
            'address'=>$row['address'],
            'url'=>$row['url']
        ]);
        OrderProduct::create([
            'sales_channele_order'=>$order->id,
            'product_id'=>$row['product_id'],
            'amount'=>$row['amount'],
            'price'=>$row['total_price']
        ]);
        return $order;
    }


}
