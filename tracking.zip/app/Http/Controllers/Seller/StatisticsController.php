<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Models\City;
use App\Models\Country;
use App\Models\Order;
use App\Models\SalesChannels;
use App\Models\Seller;
use App\WorkDayOrder;
use Illuminate\Http\Request;

class StatisticsController extends Controller
{
    //States
    //=> All
    //=> From , to
    //=> Today

    public function index(Request $request,$type_users){
        //Date that can be
        //All Days
        //Today
        //From to
        if(!$request->date) {
            $date = 'all';
        }else{
            $date = $request->date;
        }
        if(!$request->country) {
            $country = '!';
        }else{
            $country = $request->country;
        }
        if(!$request->city) {
            $city = '!';
        }else{
            $city = $request->country;
        }

        //For all users or for specific user

        if($type_users == 'all') {
            $orders = Order::get();
        }else{
            $orders = [];
            //Get Seller email with id
            $seller = Seller::find($type_users);
            $email = $seller->email;
            $shops = SalesChannels::where('owner_email',$email)->get();
            foreach($shops as $shop){
                $orders_shop = $shop->orders;
                foreach($orders_shop as $ord){
                    $orders [] = $ord;
                }
            }
        }
        //New Orders
        $new_orders = $this->ordersWithState($request, 0, $date,$orders,$country,$city);
        //Confirmed  Orders
        $confirmed_orders = $this->ordersWithState($request, 4, $date,$orders,$country,$city);
        //Delivered  Orders
        $delivered_orders = $this->ordersWithState($request, 8, $date,$orders,$country,$city);
        //Percentage
        //All Orders
        $all_orders = $this->ordersWithState($request, 'all', $date,$orders,$country,$city);
        if(count($all_orders) != 0) {
            $confirmed_percentage = count($confirmed_orders) / count($all_orders) * 100;
            $delivered_percentage = count($delivered_orders) / count($all_orders) * 100;
        }else{
            $confirmed_percentage = 0;
            $delivered_percentage = 0;
        }
        //Total Earnings
        $seller  = Seller::find($type_users);
        $shops = SalesChannels::select('id')->where('owner_email',$seller->email)->get();
        $shop_ids =[];
        foreach($shops as $shop){
            $shop_ids [] = $shop->id;
        }
        $total_earnings = $this->earningOrders($request,10,$date,$shop_ids);
        $graph_earnings =  $this->earningGraph($request,$date,$shop_ids);



        // dd($total_earnings);
        $countries =  Country::get();
        $cities =  City::get();

        $res= [
            'new_orders'=>count($new_orders),
            'confirmed_orders'=>count($confirmed_orders),
            'delivered_orders'=>count($delivered_orders),
            'confirmed_percentage'=>$confirmed_percentage,
            'delivered_percentage'=>$delivered_percentage,
            'all_orders'=>count($all_orders),
            'total_earnings'=>$total_earnings,
            'graph_earnings'=>$graph_earnings,
            'countries'=>$countries,
            'cities'=>$cities,

        ];



        return view('seller.home',compact('res','type_users'));
    }

    //Abstract Orders
    public function ordersWithState(Request $request, $status,$state,$orders,$country,$city){
        $filtered_orders =[];
        $filtered_orders2 = [];
        $filtered_orders3 = [];

        foreach($orders as $order){
            if($status != 'all') {
                if ($status == $order->status) {
                    $filtered_orders [] = $order;
                }
            }else{
                $filtered_orders [] = $order;
            }
        }
        foreach($filtered_orders as $order){
            if($country != '!'){
                if($order->country_id == $country){
                    $filtered_orders2 [] = $order;
                }
            }
        }
        foreach($filtered_orders2 as $order){
            if($city != '!'){
                if($order->city_id == $city){
                    $filtered_orders3 [] = $order;
                }
            }
        }
        return $this->dateFilter($request,$filtered_orders3,$state);
    }
    public function dateFilter(Request $request,$array,$state){
        $result = [];
        foreach($array as $arr) {
            switch ($state) {
                case 'all':
                    $result[] = $arr;
                    break;
                case 'from':
                    $order_date_from = date('Y-m-d', strtotime($request->from));
                    $order_date_to = date('Y-m-d', strtotime($request->to));
                    $order_date = date('Y-m-d', strtotime($arr->created_at));
                    if($order_date >= $order_date_from && $order_date <= $order_date_to){
                        $result[]=$arr;
                    }
                    break;
                case 'today':
                    $order_date_today = date('Y-m-d', strtotime($arr->created_at));
                    $today = date('Y-m-d', strtotime(date('Y-m-d')));
                    if($order_date_today === $today){
                        $result[]=$arr;
                    }
                    break;
            }
        }
        return $result;
    }
    public function getSellerWithOrder($order){
        return Seller::where('email',$order->shop->owner_email)->first()->id;
    }
    //Earnings
    public function earningOrders(Request $request, $status,$date,$shop_ids){
        $workdays =  WorkDayOrder::where('status',$status)->get();
        $orders = [];
        $total_price = 0;
        $today = date('Y-m-d', strtotime(date('Y-m-d')));
        foreach($workdays as $wday){
            $work_date = date('Y-m-d', strtotime($wday->created_at));
            if($date == 'today'){
                if($work_date == $today){
                    $order = $wday->order;
                }
            }elseif($date == 'from'){
                $from = $request->from;
                $to = $request->to;
                if($work_date >= $from && $work_date <= $to){
                    $order = $wday->order;
                }
            }else{
                $order = $wday->order;
            }

            if(in_array($order->sales_channel, $shop_ids)){
                $products = $order->product;
                foreach($products as $pro){
                    $total_price += $pro->price;
                }
            }


        }
        return $total_price;
    }
    public function earningGraph(Request $request,$filter,$shop_ids){
        //We have 3 cases
        //1. From start till now
        //2. All Days.
        //3. From to date.
        $orders = Order::select('id','status','created_at','sales_channel')->where('status',10)->get();
        $filtered_orders = [];
        foreach($orders as $or){
            if(in_array($or->sales_channel, $shop_ids)){
                $filtered_orders [] = $or;
            }
        }
        $orders = $filtered_orders;
        $result= [];
        $days= [];
        $today = date('Y-m-d', strtotime(date('Y-m-d')));
        if($filter == 'today'){
            foreach($orders as $order){
                $order_date = date('Y-m-d', strtotime($order->created_at));
                if($order_date == $today) {
                    $days [] = $order_date;
                }
            }
        }elseif($filter == 'all'){
            foreach($orders as $order){
                $order_date = date('Y-m-d', strtotime($order->created_at));
                $days [] = $order_date;
            }

        }elseif($filter == 'from'){
            $from = date('Y-m-d', strtotime($request->from));
            $to = date('Y-m-d', strtotime($request->to));
            foreach($orders as $order){
                $order_date = date('Y-m-d', strtotime($order->created_at));
                if($order_date >=  $from && $order_date <= $to) {
                    $days [] = $order_date;
                }
            }
        }

        $days = array_unique($days);
        foreach($days as $day ) {
            foreach ($orders as $order) {
                $order_day = date('Y-m-d', strtotime($order->created_at));
                if($order_day == $day){
                    $result[$day] []= $order;
                }
            }
        }

        foreach($result as $key => $value){
            $orders =  $value;
            $price = 0;
            foreach($orders as $order){
                $products = $order->product;
                foreach($products as $pro){
                    $price += $pro->price;
                }
            }
            $result[$key] = $price;
        }

        return $result;

    }


}
