<?php

use App\Http\Controllers\Site\Auth\ForgotPasswordController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(
    [
        'prefix' => LaravelLocalization::setLocale(),
        'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath']
    ], function () { //...
    Route::get('/', 'MainController@home')->name('site.home');

    Route::get('/get/shops/products', 'MainController@getProducts')->name('site.getProducts');
    Route::get('/get/country/cities', 'MainController@getCities')->name('site.getCities');
    Route::get('/get/country/cities/withShop', 'MainController@getCitiesWithShop')->name('site.getCities.withShopId');

    Route::get('/get/cities/zones', 'MainController@getZones')->name('site.getZones');
    Route::get('/get/cities/districts', 'MainController@getDistricts')->name('site.getDistricts');

    Route::get('/get/order/tracks/{id}', 'MainController@trackOrder')->name('site.trackOrder');


    Route::get('/join_us', 'MainController@join_us')->name('site.join_us');
    Route::get('view/login', 'Auth\LoginController@showLoginForm')->name('auth.login');
    Route::post('login/post', 'Auth\LoginController@UserLogin')->name('auth.login.post');
    Route::get('logout', 'Auth\LoginController@logout')->name('logout');

    Route::post('send/join/request', 'MainController@JoinRequest')->name('send.join.request');


    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/clear-cache', function () {
        Artisan::call('cache:clear');
        Artisan::call('config:cache');
        return 'DONE'; //Return anything
    });

    Auth::routes();
    Route::get('forget-password', [ForgotPasswordController::class, 'showForgetPasswordForm'])->name('forget.password.get');
    Route::post('forget-password', [ForgotPasswordController::class, 'submitForgetPasswordForm'])->name('forget.password.post');
    Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm'])->name('reset.password.get');
    Route::post('reset-password', [ForgotPasswordController::class, 'submitResetPasswordForm'])->name('reset.password.post');

    Route::get('/home', 'HomeController@index')->name('home');

});
