<section class='testimonails-area'>
    <div class='container'>
        <div class='row'>
            <div class='col-lg-8 offset-lg-2 sec-titile-wrapper text-center'>
                <h2 class='section-title'>Testimonials</h2>
                <p>Lorem ipsum dolor sit amet consetetur sadipscing elitr sed diam nonumy eirmod tempor invidunt labore
                    dolore magna aliquyam erat sed diam voluptua.</p>
            </div>
            <!-- end section-titile -->
            <div class='col-12 testimonilas-active owl-carousel'>
                <div class='single-testimonials text-center'>
                    <img src='{{asset('assets/site/images/all-img/t1.jpg')}}' class='rounded-circle' alt=''>
                    <h4>mahedi hasan</h4>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <p>Lorem ipsum dolor amet consetetur sadipscing elitr diam nonumy eirmod tempor invidunt labore
                        dolore magna aliquyam erat, sed diam voluptua.</p>
                    <i class='icofont icofont-quote-right'></i>
                </div>
                <!-- end single testimonilas -->
                <div class='single-testimonials text-center'>
                    <img src='{{asset('assets/site/images/all-img/t2.jpg')}}' class='rounded-circle' alt=''>
                    <h4>akramul hasan</h4>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <p>Lorem ipsum dolor amet consetetur sadipscing elitr diam nonumy eirmod tempor invidunt labore
                        dolore magna aliquyam erat, sed diam voluptua.</p>
                    <i class='icofont icofont-quote-right'></i>
                </div>
                <!-- end single testimonilas -->
                <div class='single-testimonials text-center'>
                    <img src='{{asset('assets/site/images/all-img/t3.jpg')}}' class='rounded-circle' alt=''>
                    <h4>tonmoy hasan</h4>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <p>Lorem ipsum dolor amet consetetur sadipscing elitr diam nonumy eirmod tempor invidunt labore
                        dolore magna aliquyam erat, sed diam voluptua.</p>
                    <i class='icofont icofont-quote-right'></i>
                </div>
                <!-- end single testimonilas -->
                <div class='single-testimonials text-center'>
                    <img src='{{asset('assets/site/images/all-img/t3.jpg')}}' class='rounded-circle' alt=''>
                    <h4>nazmul hasan</h4>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <p>Lorem ipsum dolor amet consetetur sadipscing elitr diam nonumy eirmod tempor invidunt labore
                        dolore magna aliquyam erat, sed diam voluptua.</p>
                    <i class='icofont icofont-quote-right'></i>
                </div>
                <!-- end single testimonilas -->
                <div class='single-testimonials text-center'>
                    <img src='{{asset('assets/site/images/all-img/t3.jpg')}}' class='rounded-circle' alt=''>
                    <h4>reza khan</h4>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <p>Lorem ipsum dolor amet consetetur sadipscing elitr diam nonumy eirmod tempor invidunt labore
                        dolore magna aliquyam erat, sed diam voluptua.</p>
                    <i class='icofont icofont-quote-right'></i>
                </div>
                <!-- end single testimonilas -->
                <div class='single-testimonials text-center'>
                    <img src='{{asset('assets/site/images/all-img/t3.jpg')}}' class='rounded-circle' alt=''>
                    <h4>kausar alam</h4>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <i class='fa fa-star active'></i>
                    <p>Lorem ipsum dolor amet consetetur sadipscing elitr diam nonumy eirmod tempor invidunt labore
                        dolore magna aliquyam erat, sed diam voluptua.</p>
                    <i class='icofont icofont-quote-right'></i>
                </div>
                <!-- end single testimonilas -->
            </div>
        </div>
    </div>
</section>
