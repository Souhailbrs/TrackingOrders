@extends("layouts.admin")
@section("pageTitle", "Users Page")
@section("style")
@endsection
@section("content")
@foreach($result as $res)
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <h1> Seller Name : {{ $res['seller']->name }}</h1>
                @foreach($res['shops'] as $shop)
                    <h2>
                        Shop Name : {{$shop->title_en}}
                    </h2>
                    <table class="table">
                        <tr>
                            <td>
                                Order Name
                            </td>
                            <td>
                                Order Quantity
                            </td>
                            <td>
                                Order Price
                            </td>
                        </tr>
                    @foreach($res['orders'] as $order)
                        <?php $order_products =  \App\Models\OrderProduct::where('sales_channele_order',$order->id)->get(); $total_result =0;?>
                        @if(count($order_products) > 0)
                            @foreach($order_products as $productt)
                                    <tr>
                                        <td>
                                            {{$productt->one_product->name}}
                                        </td>
                                        <td>
                                            {{$productt->amount}}
                                        </td>
                                        <td>
                                            {{$productt->price}}
                                        </td>
                                        <?php $total_result  += $productt->price ?>
                                    </tr>
                                @endforeach
                         @endif

                        @endforeach
                        <tr>
                            <td>
                                Total Price
                            </td>

                            <td colspan="2">
                                {{$total_result}}

                            </td>
                        </tr>
                        <?php $total_result =0 ;?>

                    </table>
                @endforeach
                <hr>
            </div>
        </div>
    </div>



@endforeach
@endsection
