<?php

return [
    'id' => 'الرقم',
    'image' => 'الصورة',
    'product' => 'المنتج',
    'price' => 'السعر',
    'customer' => 'العميل',
    'status' => 'الحالة',
    'deliver_time' => 'وقت التسليم',
    'actions' => 'التحكم',
    'search_for_anything' => 'ابحث عن أي شيء',
    'print_labels' => 'طباعة الطلبيات',
    'sent_orders' => 'الطلبيات المرسلة',
    'today_orders' => 'طلبيات اليوم',
    'all_orders' => 'كل الطلبيات',
    'controls'=>'التحكم',
    'view'=>'عرض',
    'edit'=>'تعديل',
    'delete'=>'حذف',

];
