<?php

return [
    'id' => 'ID',
    'image' => 'Image',
    'product' => 'Product',
    'price' => 'Price',
    'customer' => 'Customer',
    'status' => 'Status',
    'actions' => 'Actions',
    'search_for_anything' => 'Search For Any Thing',
    'print_labels' => 'Print Labels',
    'sent_orders' => 'Sent Orders',
    'today_orders' => 'Today Orders',
    'all_orders' => 'All Orders',
    'controls'=>'Controls',
    'view'=>'View',
    'edit'=>'Edit',
    'delete'=>'Delete',
];
