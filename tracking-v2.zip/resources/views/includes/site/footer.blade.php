<footer class='site-footer'>
    <div class='container'>
        <div class='row'>
            <div class='col-lg-4 col-md-6 col-12'>
                <div class='single-footer'>
                    <a href='#'> <img src='{{asset('assets/site/images/logo/flogo.png')}}' alt='' class='footer-logo'></a>
                    <p>Lorem ipsum dolor sit amet consetetur sadipscing elitr invidunt.</p>
                    <br>
                    <p>&copy;2018 <a href='#'>Appos</a> All Rights Reserved</p>
                </div>
            </div>
            <!-- end single footer -->
            <div class='col-lg-2 col-md-6 col-12'>
                <div class='single-footer'>
                    <h5 class='footer-title'>Company</h5>
                    <ul>
                        <li><a href='#'>Home </a></li>
                        <li><a href='#'>feature </a></li>
                        <li><a href='#'>overview </a></li>
                        <li><a href='#'>pricing </a></li>
                        <li><a href='#'>team </a></li>
                        <li><a href='#'>faqs </a></li>
                        <li><a href='#'>contacts </a></li>
                    </ul>
                </div>
            </div>
            <!-- end single footer -->
            <div class='col-lg-3 col-md-6 col-12'>
                <div class='single-footer'>
                    <h5 class='footer-title'>Useful Link</h5>
                    <ul>
                        <li><a href='#'>Term & Condition</a></li>
                        <li><a href='#'>Privacy Policy</a></li>
                        <li><a href='#'>Recent News</a></li>
                    </ul>
                </div>
            </div>
            <!-- end single footer -->
            <div class='col-lg-3 col-md-6 col-12'>
                <div class='single-footer'>
                    <h5 class='footer-title'>Company</h5>
                    <ul>
                        <li><a href='#'>Facebook</a></li>
                        <li><a href='#'>Tiwtter </a></li>
                        <li><a href='#'>Instagram </a></li>
                        <li><a href='#'>Linkedin </a></li>
                        <li><a href='#'>team </a></li>
                        <li><a href='#'>faqs </a></li>
                        <li><a href='#'>contacts </a></li>
                    </ul>

                </div>
            </div>
            <!-- end single footer -->
        </div>
    </div>
</footer>
